import RPi.GPIO as GPIO
import time
import os

pin = 14

i  = 0
filename = "/home/pi/Vibration.output"

try:
    os.remove(filename)
except:
    pass


GPIO.setmode(GPIO.BCM)
GPIO.setup(pin, GPIO.IN,pull_up_down=GPIO.PUD_UP)
while True:

    input_state=GPIO.input(pin)

                
    if(i<19):
        with open(filename,'a') as file:
            file.write(str(input_state) + " " + str(time.time()) + '\n')
            i = i +1
    else:
        #with open(filename,'w') as file:
        #    file.write(str(input_state) + " " + str(time.time()) + '\n')
        #    i=0
        with open(filename, 'r') as fin:
            data = fin.read().splitlines(True)
        with open(filename, 'w') as fout:
            fout.writelines(data[1:])
            fout.write(str(input_state) + " " + str(time.time()) + '\n')

    
    time.sleep(0.20)

GPIO.cleanup()
