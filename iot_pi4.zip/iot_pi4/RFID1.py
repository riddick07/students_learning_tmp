from pirc522 import RFID
rdr = RFID()
import time
import os


i  = 0
filename = "/home/pi/RFID1.output"

try:
    os.remove(filename)
except:
    pass

file = open(filename,'w+')

rdr.__init__(dev='/dev/spidev0.0',pin_rst=15)
rdr.set_bitmask(0x26, (0x07 << 4) )

while True:
  (error, tag_type) = rdr.request()
  if not error:
    (error, uid) = rdr.anticoll()      
    if not error:     
        if(i<19):
            with open(filename,'a') as file:
                file.write(str(uid[0]) + "," + str(uid[1]) + "," + str(uid[2]) + "," + str(uid[3]) + " " + str(time.time()) + '\n')
                i = i +1
        else:
            #with open(filename,'w') as file:
            #    file.write(str(input_state) + " " + str(time.time()) + '\n')
            #    i=0
            with open(filename, 'r') as fin:
                data = fin.read().splitlines(True)
            with open(filename, 'w') as fout:
                fout.writelines(data[1:])
                fout.write(str(uid[0]) + "," + str(uid[1]) + "," + str(uid[2]) + "," + str(uid[3]) + " " + str(time.time()) + '\n')
        time.sleep(0.5)
# Calls GPIO cleanup
rdr.cleanup()
